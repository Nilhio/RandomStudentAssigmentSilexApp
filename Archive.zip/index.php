<?php
require_once __DIR__.'/vendor/autoload.php';
require_once __DIR__.'/config/config.php';
require_once __DIR__.'/config/form.php';
require_once __DIR__.'/config/routes.php';


$app->run();
