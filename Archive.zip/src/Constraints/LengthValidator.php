<?php

namespace Constraints;

use Symfony\Component\Validator\Constraints\LengthValidator as ParentContstraint;

/**
 * Class LengthValidator
 * @package Constraints
 */
class LengthValidator extends ParentContstraint
{
}
