<?php

namespace Constraints;

use Symfony\Component\Validator\Constraints\NotBlankValidator as ParentContstraint;

class NotBlankValidator extends ParentContstraint
{
}
